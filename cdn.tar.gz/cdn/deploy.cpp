#include "deploy.h"
#include <iostream>
#include <string.h>

#include <sstream>

using namespace std;


//你要完成的功能总入口
void deploy_server(char *topo[MAX_EDGE_NUM], int line_num, const char *filename) {

    // 需要输出的内容
    char *topo_file = (char *) "17\n\n0 8 0 20\n21 8 0 20\n9 11 1 13\n21 22 2 20\n23 22 2 8\n1 3 3 11\n24 3 3 17\n27 3 3 26\n24 3 3 10\n18 17 4 11\n1 19 5 26\n1 16 6 15\n15 13 7 13\n4 5 8 18\n2 25 9 15\n0 7 10 10\n23 24 11 23";

    // 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
    write_result(topo_file, filename);

}

//你要完成的功能总入口 ex
void deploy_server_ex(const char *inputFileName, const char *outputFileName) {

    // 需要输出的内容
    char *topo_file;
            //= (char *) "17\n\n0 8 0 20\n21 8 0 20\n9 11 1 13\n21 22 2 20\n23 22 2 8\n1 3 3 11\n24 3 3 17\n27 3 3 26\n24 3 3 10\n18 17 4 11\n1 19 5 26\n1 16 6 15\n15 13 7 13\n4 5 8 18\n2 25 9 15\n0 7 10 10\n23 24 11 23";


    FILE *fin, *fout;
    fin = fopen(inputFileName, "rb");
    fout = fopen(outputFileName, "wb");
    int networkNodeCount = 0, linkCount = 0, consumeNodeCount = 0;
    fscanf(fin, "%d", &networkNodeCount);
    fscanf(fin, "%d", &linkCount);
    fscanf(fin, "%d", &consumeNodeCount);
    int costPerServer = 0;
    fscanf(fin, "%d", &costPerServer);
    fprintf(fout, "max:%d\nmin:%d\nsum:%d\ncostPerServer=%d", networkNodeCount, linkCount, consumeNodeCount,
            costPerServer);

    // 存储 节点之间的链路
    // 若节点i和j存在链路，那么graphicArray[i][j]和graphicArray[j][i]不为零
    // 如果为零可以代表 该链路已经不能再承载 流量了，也就意味着此时不存在链路
    // 数值分别代表该链路的总容量， 例如graphicArray[i][j]=20表示i->j还有20容量
    int networkGraphic[networkNodeCount][networkNodeCount];

    // 存储消费节点 跟网络节点 的链接信息
    // consumeGraphic[i][j]代表i这个用户的视频带宽消耗需求，它跟j相连
    int consumeGraphic[consumeNodeCount][networkNodeCount];

    // 存储每条链路的流量租用费用，根据题意i->j 与j->i是一样的价钱
    int costFlowPerLink[networkNodeCount][networkNodeCount];
    memset(networkGraphic, 0, sizeof networkGraphic);
    memset(consumeGraphic, 0, sizeof consumeGraphic);
    memset(costFlowPerLink, 0, sizeof costFlowPerLink);
    //一共有linkCount条网络链路
    int startNode = 0, endNode = 0, totalFlow = 0, c = 0;
    for (int i = 0; i < linkCount; ++i) {
        fscanf(fin, "%d", &startNode);
        fscanf(fin, "%d", &endNode);
        fscanf(fin, "%d", &totalFlow);
        fscanf(fin, "%d", &c);
        networkGraphic[startNode][endNode] = networkGraphic[endNode][startNode] = totalFlow;
        costFlowPerLink[startNode][endNode] = costFlowPerLink[endNode][startNode] = c;
    }

    int consumerRequire = 0, consumerNode = 0, networkNode = 0;
    //一共有consumeNodeCount个消费节点
    for (int j = 0; j < consumeNodeCount; ++j) {
        fscanf(fin, "%d", &consumerNode);
        fscanf(fin, "%d", &networkNode);
        fscanf(fin, "%d", &consumerRequire);
        consumeGraphic[consumerNode][networkNode] = consumerRequire;
    }
// print consumeGraphic test: you can remove the code annotation to print the array
//    for (int k = 0; k < consumeNodeCount; ++k) {
//        for (int i = 0; i < networkNodeCount; ++i) {
//            if (consumeGraphic[k][i] > 0) {
//                cout << k << "->" << i << "=" << consumeGraphic[k][i] << endl;
//            }
//        }
//    }

// print networkGraphic test: you can remove the code annotation to print the array
//    for (int k = 0; k < networkNodeCount; ++k) {
//        for (int i = 0; i < networkNodeCount; ++i) {
//            if (networkGraphic[k][i] > 0) {
//                cout << k << "->" << i << "=" << networkGraphic[k][i] << endl;
//            }
//        }
//    }

    int tLinkC = consumeNodeCount;
    stringstream strs;
    strs << tLinkC;
    strs << "\n";


    for (int k = 0; k < consumeNodeCount; ++k) {
        for (int i = 0; i < networkNodeCount; ++i) {
            if (consumeGraphic[k][i] > 0) {
                strs << "\n";
                strs << i;
                strs << " ";
                strs << k;
                strs << " 0";
            }
        }
    }
    string temp_str = strs.str();
    topo_file = (char *) temp_str.c_str();
    fclose(fin);
    fclose(fout);


    // 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
    write_result(topo_file, outputFileName);

}
