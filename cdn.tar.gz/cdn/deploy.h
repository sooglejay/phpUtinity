#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"
#include <iostream>
#include "stdio.h"
void deploy_server(char * graph[MAX_EDGE_NUM], int edge_num, const char * filename);

//JiangWei  code
void deploy_server_ex(const char * inputFileName,const char * filename);

	

#endif
